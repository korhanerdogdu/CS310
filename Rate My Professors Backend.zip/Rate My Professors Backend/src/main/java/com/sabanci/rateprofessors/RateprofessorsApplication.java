package com.sabanci.rateprofessors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateprofessorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateprofessorsApplication.class, args);
	}

}
