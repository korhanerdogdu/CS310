package com.sabanci.rateprofessors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateprofessorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
